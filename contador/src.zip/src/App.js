import "./App.css";
import Contador from "./componentes/Contador";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Contador />
      </header>
    </div>
  );
}

export default App;
