import "./App.css";
import Calculadora from "./components/Calculadora";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Calculadora />
      </header>
    </div>
  );
}

export default App;
